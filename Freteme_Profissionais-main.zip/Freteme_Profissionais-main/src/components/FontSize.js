export const PrimaryFontSize = 14;

export const SecondaryFontSize = 16;
export const TertiaryFontSize = 18;
