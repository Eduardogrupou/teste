# NativeBase Expo Template

The official NativeBase template for [Expo](https://docs.expo.io/)

## Usage

```sh
expo init my-app --template @native-base/expo-template
```
